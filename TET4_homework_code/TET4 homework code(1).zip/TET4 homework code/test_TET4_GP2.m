close all;
clear all;
clc;

%绘制四面体
x  = [0 0 0; 
      1 0 0; 
      0 1 0;
      0 0 1;];%四面体顶点坐标

ix=[1 2 3 4 1 3 4 2];%四面体连线顺序

nint=1:3;

for k=1:length(nint)
    figure;
    patch('vertices', x, 'faces', ix, 'facecolor', 'none', 'edgecolor', 'b');%四面体绘制
    hold on;
    [g, w] = TET4_GP(k);
    plot3(g(:, 1), g(:, 2), g(:, 3), 'marker', 'x', 'color', 'r', 'linestyle', 'none', ...
        'markersize', 16); %绘制高斯点
    view(43, 22);%视图旋转
end
 
% 贡献：熊志浩
