function [N,dN] = ShapeFun(Xi)
% ShapeFun - Description
%   give shape function of tetrahedron
% Syntax: [N,dN] = ShapeFuc(order)
%
% Long description

% N: Shape Function [N1,N2,N3]
    N...
    =   [Xi(1),Xi(2),Xi(3),1-Xi(1)-Xi(2)-Xi(3)];
    
% dN: dN/dXi ; dN(i,j)=dN(i)/dXi(j) 
    dN...
    =   [1 0 0;
        0 1 0;
        0 0 1;
        -1 -1 -1];
end

%贡献：欧阳学龙