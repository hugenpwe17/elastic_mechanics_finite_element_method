function CC = ElastTensor(D,E,nu)
% ElastTensor - Description
%   CC : ElastTensor (Ce by Ce),Ce = 3 (2D) or 6 (3D)
%   D  : Dimensionality
%   E  : Young's modulus
%   nu : Poisson's ratio
% Syntax: CC = ElastTensor(D,E,nu)
%
% Long description
    
mu = E / 2 / (1 + nu);
lm = E * nu / (1 + nu) / (1 - 2 * nu); 
switch D
    case 2
        CC = [...
            2 * mu + lm, lm, 0;
            lm, 2 * mu + lm, 0; 
            0, 0, mu]; 
    case 3
        CC = [...
            2 * mu + lm, lm, lm, 0, 0, 0;
            lm, 2 * mu + lm, lm, 0, 0, 0; 
            lm, lm, 2 * mu + lm, 0, 0, 0;
            0, 0, 0, mu, 0, 0;
            0, 0, 0, 0, mu, 0;
            0, 0, 0, 0, 0, mu];
    otherwise
        error('illegal dimensionality');
end
end